package fpdual.empresa.crud.servicio;

import java.util.List;

import fpdual.empresa.crud.entities.Empleado;
import fpdual.empresa.crud.entities.Empresa;

public interface ServicioEmpresa  {

	public void guardarEmpresa(Empresa empresa, List<Empleado> empleados);
	public List<Empresa> listarEmpresas();
}
