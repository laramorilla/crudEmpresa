package fpdual.empresa.crud.servicio.implementacion;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fpdual.empresa.crud.entities.Empleado;
import fpdual.empresa.crud.entities.Empresa;
import fpdual.empresa.crud.repository.RepositorioEmpresa;
import fpdual.empresa.crud.servicio.ServicioEmpresa;

@Service
public class ServicioEmpresaImpl implements ServicioEmpresa{
	
	@Autowired
	private RepositorioEmpresa repositorio;

	@Override
	public void guardarEmpresa(Empresa empresa, List<Empleado> empleados) {
		Empresa empresaNueva = new Empresa();
		if(!empleados.isEmpty()) {
			empleados.forEach(empleado -> {
				empresaNueva.addEmpleados(empleado);
			});
		}
		empresaNueva.setNombre(empresa.getNombre());
		this.repositorio.saveAndFlush(empresaNueva);
	}

	@Override
	public List<Empresa> listarEmpresas() {
		return this.repositorio.findAll();
	}

}
