package fpdual.empresa.crud.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import lombok.Data;

@Entity(name = "Empresa")
@Table(name = "empresa")
@Data
public class Empresa {

	@Id
    @GeneratedValue
    private Long id;
 
	@Column(name="nombre")
    private String nombre;
    
	@OneToMany(
	        mappedBy = "empresa",
	        cascade = CascadeType.ALL,
	        orphanRemoval = true
	    )
	private List<Empleado> empleados = new ArrayList<>();
	
	public void addEmpleados(Empleado empleado) {
		empleados.add(empleado);
		empleado.setEmpresa(this);
    }
 
    public void removeEmpleados(Empleado empleado) {
    	empleados.remove(empleado);
        empleado.setEmpresa(null);
    }
}
