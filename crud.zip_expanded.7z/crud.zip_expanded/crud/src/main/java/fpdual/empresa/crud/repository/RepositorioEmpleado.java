package fpdual.empresa.crud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import fpdual.empresa.crud.entities.Empleado;

public interface RepositorioEmpleado extends JpaRepository<Empleado, Long> {

}
