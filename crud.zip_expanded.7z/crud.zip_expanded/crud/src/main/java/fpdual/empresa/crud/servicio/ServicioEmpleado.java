package fpdual.empresa.crud.servicio;

import java.util.List;

import fpdual.empresa.crud.entities.Empleado;

public interface ServicioEmpleado {
	
	public void borrarEmpleado(Long id);
	public List<Empleado> listaEmpleados();

}
